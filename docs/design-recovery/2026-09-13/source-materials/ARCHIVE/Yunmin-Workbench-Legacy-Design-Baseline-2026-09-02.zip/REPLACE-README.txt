Yunmin Workbench · doc replacement pack · 2026-09-02

建议操作：
1. 先备份当前 doc/。
2. 删除/移出旧的 4 个 2026-08-30 顶层文件：
   - 00-EXECUTOR-PROMPT.txt
   - CLEAN-ROOM-GREEN-2026-08-30-FINAL.md
   - Yunmin-Workbench-Docs-Refresh-2026-08-30.zip
   - Yunmin-Workbench-E-Executor-Handoff-Pack-2026-08-30.zip
3. 把本包 doc/ 下的新 4 个文件放进去。
4. 这些仍是本地 handoff/docs 资料，不应默认提交进产品代码 Git。

新四件：
- 00-EXECUTOR-PROMPT.txt
- CURRENT-STATE-2026-09-02.md
- Yunmin-Workbench-Docs-Refresh-2026-09-02.zip
- Yunmin-Workbench-E-Executor-Handoff-Pack-2026-09-02.zip
