# Yunmin Workbench · CURRENT STATE SNAPSHOT
日期：2026-09-02（Asia/Shanghai）

> 本文件是快速接班快照，不是 Source of Truth。任何 SHA、测试数、能力状态都必须先以当前 Git / 文件 / Runtime / tests 复核。

## 1. 产品定义
正式名称：**Yunmin Workbench**；Agent Workbench 仅为类别名。它是 Governance Layer、Personal Overlay/Profile、Project/Git/Harness 之上的用户工作空间与 Harness Control Plane。Workbench 负责 UI、Context staging、Packet、Manual Context、Activity/History/Memory/Attention 等 Workbench-owned projection/state；Governance、Project/Task/Gate、Harness Runtime、Git/files/tests、Artifact 仍是外部 SOT。

主路径：`Project → Conversation/Session → Context → Agent(s) → Dispatch → Runtime Execution → Result → Parallel/Handoff/Compare`。
长期 IA：Session 是核心工作面；多 Session 持续可见；Context/Packet/Evidence/Runtime 按需浮现；Map/Trajectory 是同一 workspace 的另一种关系视图，不是独立管理后台。

## 2. 稳定主干
截至本快照，稳定 main 已到：
`3f21ca1d1b0b5c3ef0eaee093a154c7e27a68bb1` — `fix(runtime): separate workbench execution identity`

该主干已包含：
- Governance product binding：Session/Packet 能投影既有 ProjectAdapter / DialogueRegistry provenance；不新增 Governance schema。
- Runtime correctness：Workbench execution identity 与 native session ref 分离；Claude tool_result 保留关联；Codex approval / needs-input capability 修正为 NO。
- 核心 11/11 CLOSED，以及 History/Search、Attention、Portability、Memory、Ambient/Material、Harness Expansion、Runtime Inspector、Hardening/Scale。

## 3. 当前产品体验分支
`phase/demo-multisession @ 7b5960d`：Creative OS Demo 已扩为 6 Sessions，但只是 checkpoint，不应单独合入。

`phase/product-experience-recovery @ c4b588d`：当前产品体验候选，已完成方向包括：
- 删除旧 `styles.css` 与 `material/product-integration.css` 的竞争，Renderer 只加载 `material-surfaces.css + product-rebuild.css`；
- persistent Workspace/Session rail；
- 预填充完整 Demo fixture：6 Creative OS conversations、Single、Parallel、Handoff、Approval/Needs-input、Compare、Map、Context、Frozen Packet、Memory、History、Attention；
- overlay/drawer/popover 位置与 scroll/z-index 大幅重整。

**但 c4b588d 不是可直接合并版本。** 已知必须清理：
1. 误提交 `.reasonix/**` 与 `doc/**`，需从 branch Git 结果移除但不能删除用户本地资料；
2. `demoEnvironment.ts` 通过 polling + monkey-patch `window.wb.*` 切 Demo 数据，不符合 frozen architecture；应改为明确 store/service/data-source seam，正式组件继续共用同一接口。

## 4. Claude Code 2.x 审计结论
Claude Code Agent View 证明“持续 multi-session 工作面”比 modal Session Picker 更适合高并行 Agent 使用。Yunmin 直接采用：常驻 roster、Needs input/Approval/Working 优先、peek→深度 Session 的思路；适配采用：independent session / subagent / teammate / background task 的层级表达；明确不采用：shared task list、自动认领、team lead 权威、Workbench mailbox 作为新 SOT。

Yunmin 自己的优势必须保留：Conversation / Execution 分离；Handoff 使用 `A result → sourceRef → explicit Context → B dispatch`；TaskState / RuntimeState / AttentionState 分离；Governance 不被 Workbench 重建。

## 5. Harness 能力边界
Codex：Dispatch YES / Observe YES / Receipt YES / Approval NO / NeedsInput NO / external Resume NO。
Claude：Dispatch YES / Observe YES / Receipt YES / live child Cancel 仅在真实支持时开放 / external Resume NO。
DeepSeek：没有经验证的稳定 structured runtime，禁止 heuristic 假 live。
所有 capability 必须来自真实 adapter/probe，UNKNOWN 不猜。

## 6. R0 不可回退
Frozen packet：per-file validation、corruption isolation、atomic temp+rename、serialization、max(valid)+1、summary-only list/lazy detail；renderer ErrorBoundary、single instance、Copy/Freeze/Dispatch 错误可见、5MB precheck、bounded concurrency；Activity JSONL crash-partial tolerance、malformed isolation、byte-bounded paging；Overlay no-write；missing Codex、single-instance、corrupt frozen 等关键路径不得删除。

## 7. 当前最重要的下一步
先完成 `phase/product-experience-recovery` 的 hygiene + Demo data-source architecture correction，再做一次完整 Electron walkthrough。只有体验与架构都通过后才进入 merge review。不要继续扩 Governance/Runtime，也不要把 peek/cross-session messaging/Agent Teams 后端化作为当前阻塞项。
