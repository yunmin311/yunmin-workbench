# Yunmin Workbench · Donor Screening 2026-08-30

> 目的：对 2026-08-30 用户补充项目与一次横向 GitHub 扩搜做统一筛选。这个文件保存“为什么留下/为什么淘汰”的研究依据；长期执行结论进入 REUSE-MAP，当前产品基准只保留稳定产品方向，不复制完整 donor 列表。

## 1. 最终结论

这轮没有发现应该推翻 Session Spine、Projection Integrity 或当前 CLEAN-ROOM GREEN → History/Search → Attention 路线的新项目。真正新增的价值集中在两个未来层：**Material Layer / Ambient Surface** 与 **evidence-backed Memory**。

最终升权：`hicccc77/electron-liquid-glass`、`hwyuanzi/LiquidGlass-UI`、`manikosto/notch-agents`、`DaliBerr/Vibe-Halo`、`diqierjia/StrataGate-AgentMemory`、`JiaXtian/MemoryLedger`、`hyungchulc/memory-forest`；用户原有 `TO-DO-Panel` 与 `gebai` 保留；`DSH-Transparent-UI-Plugin` 降为纯视觉机制参考；`metis` 只留局部 verification/worktree 参考；`minimind` 与 Workbench 主线隔离。

## 2. Visual / Material

**Primary implementation candidate — electron-liquid-glass**  
`hicccc77/electron-liquid-glass@0684fe7fd74855e4b13bd3e8d7b6db40f91e132a` · MIT。它不是普通 CSS glassmorphism，而是在 Windows 上给 Electron 透明窗口提供独立 native backdrop panel：DXGI Desktop Duplication + D3D11 + DirectComposition，负责真实 refraction/blur/dispersion，Electron 本身只画文字、边框、tint/highlight。对 Yunmin 的价值比 DSH Aqua 更直接，因为 Yunmin 当前就是 Electron，并且 E 是 Windows。决策：**ADAPT CANDIDATE / LATER**，只在视觉层稳定后做 spike，不能让 native effect 侵入产品状态模型。

**Primary material-system reference — LiquidGlass-UI**  
`hwyuanzi/LiquidGlass-UI@293328c3a983b55460b488bffb2caa6f25729c2f` · MIT。最有价值的是 tokenized material、progressive degradation、reduced-motion / reduced-transparency / contrast 等可访问性边界，而不是某个具体卡片造型。决策：**REFERENCE / ADAPT PATTERN / LATER**。

**DSH Aqua — reference only**  
`WYH66666666/DSH-Transparent-UI-Plugin@d94431a95bd147c11ef3fe95fa1915d1e96b028b` · AGPL-3.0。保留其 Mica / Compatibility 双模式、总开关恢复 stock UI、blur/frost/backdrop 分离的思想；作者已明确插件 API 跟不上新 DSH，安装可能 crash，因此不 COPY、不作为实现底座。决策：**REFERENCE ONLY**。

长期产品方向因此不是“把所有页面做成玻璃”，而是把材质抽成独立 `Material Layer`：结构、Projection 与交互合同不变；材质可以在 Pure / Frost / Glass 等模式间切换，并具备低性能/高对比/减少透明度降级路径。

## 3. Ambient Surface / Dynamic Island

**Best agent-specific interaction reference — Notch Agents**  
`manikosto/notch-agents@5efa73868e3af2aa5a6f493b11b0fa4eedc3668a` · MIT。它比普通 Notch TODO 更接近 Yunmin：Claude Code / Codex / Cursor 同时显示；完成后摘要；需要 approval / question 时直接在 island 处理。决策：**REFERENCE / LATER**。macOS 实现不直接搬，但信息密度与 intervention flow 值得复用。

**Best cross-platform failure semantics — Vibe Halo**  
`DaliBerr/Vibe-Halo@25e5f6f2be691b6fd51b24422bfbb8f3d0983f3a` · AGPL-3.0。最有价值的是：只有需要介入时出现、所有客户端共享一个 queue、来源明确、close/disconnect/timeout/malformed/unknown option 时回退 native client flow，不替用户发明决策。决策：**REFERENCE ONLY / LATER**。这套 fail-open-to-native-UI 语义应成为 Yunmin Ambient Surface 的安全边界。

**TO-DO Panel — keep as morphology reference**  
`xiaopu-ai/TO-DO-Panel@9db3a75743a1f5b15a0dacf37b9c87ea84dff548` · MIT。保留“折叠为极小顶部入口 → 展开为本地工作台”、不抢焦点完成提醒、local-only notification bridge、隐藏组件释放资源等产品形态。不要复制其 TODO/笔记/录音等业务模块。决策：**REFERENCE / LATER**。

最终形态定义：`Main Window = Session Spine`；`Ambient Island = Attention Projection`。Island 不是第二个 Workbench，也不是 Home Dashboard；只显示有证据的 approval / needs-input / completion / error / STALE/INVALID 等少量干预项，点击回到主窗口对应 Session。

## 4. Memory / Evidence

**Primary memory research donor — StrataGate**  
`diqierjia/StrataGate-AgentMemory@28e0906445a28c9cafe61cd46844b1395cdbfbf5` · MIT。当前最贴 Yunmin 的 memory donor：L0-L5 派生视图不覆盖 L5 source；Event 保留 source block/message、mentionedAt 与 happenedAt、supersedes/conflicts；retrieval 后用 bounded evidence gate 判断 sufficient/partial/wrong；只对最终答案真正使用过的 memory 做 reinforcement。决策：**REFERENCE / ADAPT CANDIDATE / AFTER HISTORY**。不能直接成为第二 Memory SOT，也不能绕过 Context Staging 自动注入。

**Governed-memory semantics reference — MemoryLedger**  
`JiaXtian/MemoryLedger@efac213747e5da27e70d77d08b7a31053900b6fe` · Apache-2.0。亮点是 immutable source event、append-only claim transition、valid-time + transaction-time、SUPERSEDED/DISPUTED/EXPIRED/TOMBSTONED、以及 `CONTEXT_ONLY / ANSWER / PLANNING / TOOL_ARGUMENT / AUTO_ACTION` consequence tiers。它对 Yunmin 的价值不是“再造 Memory DB”，而是提供“某条记忆允许影响到什么程度”的语义参考。决策：**REFERENCE / LATER**。

**Retrieval navigation reference — Memory Forest**  
`hyungchulc/memory-forest@3ffeffc110ed29fffaee0b26e8035d7436374608` · GPL-3.0。最值得借的是“先返回 route，再返回 memory body”、Markdown 可读证据、raw chronology bounded JSONL、derived index 可删除重建；这与 Yunmin Context Staging / Reference locator 非常契合。决策：**REFERENCE ONLY**。

本轮搜索还看了 Enfold、MASE、varve、agent-memory-system、Pallium、Quipu 等。它们各有价值，但与 StrataGate + MemoryLedger + Memory Forest 的覆盖高度重复，或者更容易把 Yunmin拖成第二 Governance/Memory 平台，因此不进入主 Donor Map。

## 5. Agent / Verification semantics

**Gebai — keep**  
`xuxinle/gebai@47d92b873e96f53698eee15079fac73055205d92` · MIT。保留 `agent_load`（能力并入当前上下文）与 `agent_run`（隔离新会话，只返回结果）的明确区分，以及 approval → code change → test → rollback 的 gate 结构。它能帮助 Yunmin表达 `Capability available ≠ Context injected ≠ Execution started`。不要借 self-optimize、AgentEngine、Sandbox 或第二 runtime。决策：**REFERENCE / LATER**。

**Metis — downgrade**  
`Wholiver/metis@ad8679a3d82f089ac17a77896e579157bdd0b95e` · MIT。只保留 verification gate、worktree isolation、session/compaction 的局部工程参考。recursive coordinator/planner/implementer/reviewer/verifier 与 Yunmin Governance/Harness 边界冲突，不进入产品层。决策：**BACKGROUND REFERENCE**。

横向搜索还发现 Agent Control Center Core、BeforeDone、LACP、pi-subagents 等 verification/orchestration 项目。它们和现有 Governance / R0 reliability / clean-room gate 重叠太高，不值得加入长期 donor 正本。

## 6. Local small model

`jingyaogong/minimind@e84156818aec24ebf0628010d89c9f5d79ea2af5` · Apache-2.0。MiniMind 是很好的 LLM 从零训练/Agentic RL 学习资产，但不是 Yunmin Workbench donor。未来如果确实需要本地、低成本、低风险 utility model，可用于 title/tag/classification/ranking 的实验 benchmark；禁止让这类小模型直接决定 Governance、TaskState、memory evidence sufficiency 或自动 action。决策：**ADJACENT RESEARCH / OUTSIDE CORE**。

## 7. 这轮真正进入长期文件的内容

REUSE-MAP：加入 `Material Layer`、`Ambient Surface`、StrataGate/MemoryLedger/Memory Forest、Gebai 的分层决策和固定 SHA；DSH Aqua、Metis、MiniMind 明确降级；新增 electron-liquid-glass、LiquidGlass-UI、Notch Agents、Vibe Halo。  
Product Book：只加入两个长期产品方向，不复制 donor 清单——`Material Layer` 与 `Ambient Island = Attention Projection`；Memory 只增加“保留 source / evidence sufficiency / retrieval 不等于使用”作为未来研究约束。  
THIRD_PARTY_NOTICES：**不改**。本轮没有新代码 COPY/ADAPT 进入 Yunmin。
