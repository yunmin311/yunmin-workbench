# Yunmin Workbench · Docs Refresh 2026-08-30

替换 doc 文件夹中旧的 FROZEN v2 / REUSE-MAP v2 时使用。

- Product Book v3：当前长期执行基准；只新增未来 Material Layer / Ambient Island 和 Memory 研究约束，不改变当前 CLEAN-ROOM GREEN → History/Search → Attention → Portability 路线。
- REUSE-MAP FINAL v3：唯一完整 donor / reuse / license / fixed-SHA 正本。
- DONOR-SCREENING：保存本轮用户项目 + 横向搜索的筛选依据；它不是执行 Source of Truth。
- THIRD_PARTY_NOTICES 不在本包中，因为本轮没有新 donor 代码 COPY/ADAPT 进入仓库。

当前远端 main 在打包时仍为 e7bb5d5fcf6108081512af9249708dde595faed3；如果 WorkBuddy/Codex 已产生新提交，以 E 上实际 origin/main 为准。
