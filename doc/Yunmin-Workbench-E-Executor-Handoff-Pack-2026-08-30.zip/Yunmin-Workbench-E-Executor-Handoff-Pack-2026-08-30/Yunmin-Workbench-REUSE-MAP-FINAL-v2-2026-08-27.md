# Yunmin Workbench · REUSE-MAP
**E Final v2 · 2026-08-27**

> 工程复用、Donor 决策与许可证溯源正本。原《项目完整描述》负责产品为什么存在与稳定产品合同；《E Long-Term Baseline》负责当前执行基准；本文件只回答“哪些能力直接用、哪些 donor 借什么、哪些不能搬、未来复制代码时如何留证”。

## 1. Reuse Policy

Yunmin Workbench 只创造自己的产品语义、Projection、Context / Packet / Canvas 交互；通用基础设施、现有 Governance / Personal Overlay、Harness 原生能力和成熟算法优先复用。稳定数据流仍是 `Governance Kernel + Personal Overlay + Project / Git / Harness → Adapter / Normalize → Projection → Interaction`。任何 History index、SQLite、Canvas、Timeline、cache 都只是 projection / derived state，不成为第二 Source of Truth。

Donor 必须按“层”比较，不能拿 History 指标淘汰 UI donor，也不能因为某 donor 功能多就让它接管 Yunmin。`COPY / ADAPT / REFERENCE / LATER / SKIP` 是模块级决策，不是整仓评级。任何 COPY/ADAPT 都要固定 repo + exact commit/tag + 原文件；只有真正进入 Yunmin 代码并产生许可证义务的内容才写入 `THIRD_PARTY_NOTICES.md`。研究型背景参考可以不进入 Frozen Provenance Index，但必须显式标记 `BACKGROUND REFERENCE / UNPINNED`，避免与可复现实验依据混淆。

## 2. 当前真实依赖

当前 `main=e7bb5d5fcf6108081512af9249708dde595faed3` 的 `package.json` 实际依赖是：Electron / electron-vite；React / React DOM；TypeScript / Vite；`@xyflow/react`；Dagre；cmdk；Zustand；Zod；simple-git；chokidar；js-yaml；`@noble/hashes`；Vitest；Playwright。它们才是 **CURRENT USE**。

| 能力 | 当前决策 | 来源 |
|---|---|---|
| Desktop host / build | CURRENT USE | Electron + electron-vite + Vite |
| Renderer | CURRENT USE | React + TypeScript |
| Canvas | CURRENT USE | `@xyflow/react` |
| Canvas layout | CURRENT USE | Dagre；复杂 nested/ports 才评估 ELK.js |
| Command Palette | CURRENT USE | cmdk |
| State / schema | CURRENT USE | Zustand + Zod |
| Git / YAML / watch / hashing | CURRENT USE | simple-git + js-yaml + chokidar + `@noble/hashes` |
| Testing | CURRENT USE | Vitest + Playwright |
| shadcn/ui / ReUI / react-resizable-panels / dnd-kit / react-markdown / MSW | APPROVED IF NEEDED | 当前未安装 |
| TanStack Virtual / `@parcel/watcher` | APPROVED IF NEEDED | 只有真实长列表/高频 watcher 性能问题出现后引入 |
| Monaco / xterm.js / node-pty / ELK.js | LATER | 不提前引入 editor/terminal/复杂 graph engine |

## 3. Layered Donor Map

### L1 · Session / History / Search

**Klovi — ADAPT / NEXT。** `cookielab/klovi@dd4e06b8f52b95a4768302930ad73543b93cf54d`，MIT。仍是多 Harness History importer/parser 的首选基础：`plugin-core/src/jsonl-stream.ts`、plugin registry/types、Claude/Codex/OpenCode parsers。保留 sourceRef、parse problems、partial-line safety；删掉不可靠 lifecycle 推断；绝不建立第二 Session truth。

**csx — ADAPT / NEXT。** `mysqto/csx@08a8d1c66240b9417b759db754ffaa4c8aa10536`，MIT。重点借 `SessionSource → canonical MessageRecord/SessionMeta`、per-file watermark incremental sync、SQLite FTS5/trigram、scope filtering、optional daemon/MCP。`ask`/RAG 不进入默认主链，retrieval 结果必须经过 Yunmin Context Staging。

**sessionwiki — ADAPT CANDIDATE / NEXT。** `youdie006/sessionwiki@eef72642a80bed9d3b767b87c91d0137b9b25780`，MIT。重点借多工具 Adapter、增量 FTS5、`trace file→session`、resume/brief 和 archive 技术。其 distilled archive 很有价值，但“Workbench 是否长期保存外部 transcript 副本”仍是独立产品 retention 决策；即使未来采用，也只能是 historical snapshot，不是 live Runtime truth。

**Claude Code History Viewer — REFERENCE / ADAPT ALGORITHM。** `jhlee0409/claude-code-history-viewer@b5f583e5f97d8d768b49229c2eb5c0a5a2c39070`，MIT。保留 byte-offset continuation、mtime/size invalidation、pagination、per-file invalidation、warm/cold equivalence 测试思想。

**CASS — REFERENCE ONLY。** `Dicklesworthstone/coding_agent_session_search@a1509629e20eae5e454703dd22549093b0aa5224`。多-agent index、atomic lexical publish、quarantine/doctor、稳定 robot schema 值得参考；LICENSE 带 OpenAI/Anthropic rider，因此不按普通 MIT COPY。

### L2 · Context / Memory / Retrieval

**Melchizedek — ADAPT PATTERN / NEXT。** `louis49/melchizedek@305361244239912684dd7f71c05a6a298c80776e`，MIT。借 `search → context → full` progressive retrieval、BM25 graceful fallback；不借第二 Memory System 语义，也不允许搜索结果自动注入 Context。

**Archiv — REFERENCE。** `Nan0pk/Archiv@dd6ba02d50826e34895a284c5b9b24af75b01d4b`，Apache-2.0。参考 canonical originals / rebuildable derived index / bounded deterministic capability / validator / provenance 分层；当前只借架构合同，不作为现成 RAG backend。

**Lore — REFERENCE。** `DnaMes/lore@9ffb3eefc7ce49dec9daba830f4d1647c096a58d`。用于理解 History Archive 与 shared memory 可以共存但必须保持 provenance 和 truth 分层；不建立第二 Memory truth。

### L3 · Skills / MCP / Personal Adaptation

**agentpack — ADAPT CANDIDATE / NEXT。** `OlegHQ/agentpack@33f2223006406c3767d6ffa9fb34cc75114be209`，MIT。借 `manifest → exact commit/content hash lockfile → content-addressed cache → per-harness staging` 与跨 Harness artifact conversion；不让 agentpack 成为新的用户规则正本。

**harness-sync — ADAPT PATTERN / NEXT。** `lukaszraczylo/harness-sync@c5707acfd3ff25b8038de2ae03b366a117980b52`，MIT。借 capability matrix、只覆盖自己拥有的 key、3-way merge、dry-run、rollback、missing-secret fail closed；其 canonical tree 不能取代 Personal Overlay / Governance。

**Grimoire — REFERENCE / ADAPT CANDIDATE。** `grimoire-rs/grimoire@4e57da1cde2f2f67a92943a13921fc5f4e477fde`，Apache-2.0。借 digest lock、跨客户端 capability truth，以及“目标 Harness 没有真实支持面就明确 skip，不伪装安装成功”的纪律。

**AnySearch Skill — REFERENCE。** `anysearch-ai/anysearch-skill@4d6cef918e9338c9deef43b81ac0f7e22606825f`，Apache-2.0。借稳定 `SKILL.md` 与 machine-specific runtime choice 分离、一次探测后落盘、同一能力跨 Claude/Codex/OpenCode 等宿主包装；不把其搜索服务本身作为 Yunmin Search backend。

**mode-io/skill-manager — REFERENCE。** `mode-io/skill-manager@6ca969cbbc2e6b9a0de719858a68b33b3c37844a`。仍可参考 unified inventory / marketplace / Windows harness binding，但 lock/hash/reproducibility 与安全 merge 优先看 agentpack / harness-sync / Grimoire。

### L4 · Activity / Attention / Trajectory / Communication

**DPlex — ADAPT / NEXT。** `Ron537/DPlex@ad832206a593b983cfe30772c658aec67b8ce568`，MIT。继续作为 Attention donor：`attentionService.ts`、`spaceAttention.ts`、`searchRegistry.ts`；只接受明确 runtime/session ref，不用 cwd/provider pairing 猜 identity。

**WorkSpaces — REFERENCE / ADAPT。** `fairchild/workspaces@4b2c460c70871964f253dafcf617ad17aa668198`，Apache-2.0。参考显式 Hook、event dedup、bounded transcript tail、历史副本与 live truth 分离。

**causetrace — REFERENCE / LATER。** `milkoor/causetrace@c7fce56f58e21368e4454e5cd830c3a1afc9c262`，MIT。参考 causal tree/DAG、`why` 链和 event provenance；heuristic causal edge 必须保持 INFERRED。

**EigenFlux + Live — REFERENCE / LATER。** `phronesis-io/eigenflux@8d9679a7c89d9d87d5e580c610a4abebd541f296`；modified Apache-2.0 + trademark condition。参考 profile/capability、broadcast vs DM、verified identity、receipt/privacy boundary，以及 Live 页 `All / Supply / Demand / Info / Alert` 的 signal taxonomy 和轻量 attention surface；当前不接入 network，不引入 heartbeat/scheduler/orchestrator。

### L5 · Renderer / Desktop UX

**Reasonix — ADOPTED / NOTICE PRESENT。** 实际适配快照：`esengine/DeepSeek-Reasonix@9b7a573ac3a94b0a2313480181374464978e5ae9`（tag `studio-v2.7.0`），MIT。已用于 deterministic graph layout 与 pane/chrome/composer/on-demand-panel interaction structure；当前 `THIRD_PARTY_NOTICES.md` 已记录完整来源和 MIT 文本。

**Cockpit — ADOPTED INTERACTION PATTERN / NOTICE PRESENT。** `Surething-io/cockpit@f0328f4420217e41e5b4d710e5caa142faaa865b`，MIT。已借 transcript/tool/file-change chronology 与 expandable tool detail；不使用其 runtime/snapshot APIs。

**cdesktop — REFERENCE / NOTICE PRESENT。** `cdesktop-ai/cdesktop@75bd015e88f9797d785c9fabcfca03c7151fd5cc`，Apache-2.0。只研究 workspace/session/diff/approval morphology；没有复制代码。

### L6 · Migration / Portability

**Chronicle — REFERENCE / ADAPT CANDIDATE。** `geekmuse/chronicle@1b9044c757b7111d6b782b44a608a1ae63d9a9b8`，MIT。借 `{{SYNC_HOME}}` / machine-local token canonicalization、round-trip invariant、doctor、partial materialization 思想。不要直接采用其 Git transport/CRDT/原地 session rewrite；Yunmin 的最终 rebinding/transport 仍未拍板。

**chezmoi / VS Code userData sync — BACKGROUND REFERENCE / UNPINNED。** 只用于 path rebinding、template 化路径和 secret exclusion 的一般工程参考；当前没有从其源码 COPY/ADAPT，也不是冻结 donor，因此不进入 Provenance Index。

### L7 · Future SaaS Action Layer

**OpenConnector — FUTURE ADAPTER / NOT NOW。** `oomol-lab/open-connector@5960f2ac0fe3e07a61c1c466e98157ad7e80b373`，Apache-2.0。只保留 Action Contract、Connection Identity + permission grants、progressive tool disclosure；未来如果多个 Harness 需要共用 Gmail/Slack/Notion/GitHub connection，可作为独立外部 subsystem。当前核心不接。

## 4. Projection Integrity 在 Reuse 中的硬边界

History parser/index 不能成为 live Runtime truth；retrieval 不得默认把结果偷偷注入当前 Context；cwd / filename / title similarity 不能变 canonical identity；Communication donor 不能扩成 scheduler/orchestrator；Skills sync donor 不能取代 Personal Overlay；Archive donor 不能自动获得永久 retention 所有权；causal donor 的 heuristic edge 不能升级为 VERIFIED/OBSERVED；任何 cache/index 都必须可删除重建或明确标注为 Workbench-owned historical snapshot。

## 5. 当前执行顺序

**Gate 0：E CLEAN-ROOM GREEN。** 修 `pnpm-workspace.yaml allowBuilds`、固定 Node/pnpm、稳定 E2E、核验 draft timeout、移除机器相关 test probe；从完全未修改的新 clone 通过 install → typecheck → build → Vitest → Playwright。

**Phase 1：History / Search。** 先实现只读 Claude + Codex History adapter/index/search；以 Klovi parser contract 为底，优先评估 csx watermark/schema 与 sessionwiki trace/archive，History Viewer 保留增量算法参考。所有 parse problem/provenance 必须显式；index/cache 放 Electron userData。

**Phase 2：Attention。** 基于真实 ActivityEvent/runtime/session ref 接 DPlex reducer；不猜状态。

**Phase 3：Portability / Reliability。** 再处理 project-root rebinding、Profile Bundle、activity partial-tail/flush/fsync、真实大数据量时的 virtualization/SQLite WAL。Chronicle 只作为 canonicalization 参考，不预先决定 transport。

UI 大改、Task Board、第二 Runtime、SaaS connector、A2A、复杂 tracing 都不在当前主线。

## 6. Donor Provenance Index

下表只列固定快照。`BACKGROUND REFERENCE / UNPINNED` 不进入；`THIRD_PARTY_NOTICES` 只在实际 COPY/ADAPT 进入代码时更新。

| Layer | Repo / exact snapshot | 决策 | License | Notices |
|---|---|---|---|---|
| Renderer | `esengine/DeepSeek-Reasonix@9b7a573ac3a94b0a2313480181374464978e5ae9` (`studio-v2.7.0`) | ADOPTED / ADAPT | MIT | `THIRD_PARTY_NOTICES.md` |
| Renderer | `Surething-io/cockpit@f0328f4420217e41e5b4d710e5caa142faaa865b` | ADOPTED PATTERN | MIT | `THIRD_PARTY_NOTICES.md` |
| UX | `cdesktop-ai/cdesktop@75bd015e88f9797d785c9fabcfca03c7151fd5cc` | REFERENCE | Apache-2.0 | `THIRD_PARTY_NOTICES.md` ref-only |
| History | `cookielab/klovi@dd4e06b8f52b95a4768302930ad73543b93cf54d` | ADAPT / NEXT | MIT | — |
| History | `jhlee0409/claude-code-history-viewer@b5f583e5f97d8d768b49229c2eb5c0a5a2c39070` | REFERENCE / ALGO | MIT | — |
| Attention | `Ron537/DPlex@ad832206a593b983cfe30772c658aec67b8ce568` | ADAPT / NEXT | MIT | — |
| Events | `fairchild/workspaces@4b2c460c70871964f253dafcf617ad17aa668198` | REFERENCE / ADAPT | Apache-2.0 | — |
| History | `mysqto/csx@08a8d1c66240b9417b759db754ffaa4c8aa10536` | ADAPT / NEXT | MIT | — |
| History | `youdie006/sessionwiki@eef72642a80bed9d3b767b87c91d0137b9b25780` | ADAPT CANDIDATE | MIT | — |
| Adaptation | `OlegHQ/agentpack@33f2223006406c3767d6ffa9fb34cc75114be209` | ADAPT CANDIDATE | MIT | — |
| Adaptation | `lukaszraczylo/harness-sync@c5707acfd3ff25b8038de2ae03b366a117980b52` | ADAPT PATTERN | MIT | — |
| Adaptation | `grimoire-rs/grimoire@4e57da1cde2f2f67a92943a13921fc5f4e477fde` | REFERENCE / ADAPT | Apache-2.0 | — |
| Skills | `anysearch-ai/anysearch-skill@4d6cef918e9338c9deef43b81ac0f7e22606825f` | REFERENCE | Apache-2.0 | — |
| Skills | `mode-io/skill-manager@6ca969cbbc2e6b9a0de719858a68b33b3c37844a` | REFERENCE | verify before COPY | — |
| Retrieval | `louis49/melchizedek@305361244239912684dd7f71c05a6a298c80776e` | ADAPT PATTERN | MIT | — |
| Memory | `DnaMes/lore@9ffb3eefc7ce49dec9daba830f4d1647c096a58d` | REFERENCE | verify before COPY | — |
| Provenance | `Nan0pk/Archiv@dd6ba02d50826e34895a284c5b9b24af75b01d4b` | REFERENCE | Apache-2.0 | — |
| Migration | `geekmuse/chronicle@1b9044c757b7111d6b782b44a608a1ae63d9a9b8` | REFERENCE / CANDIDATE | MIT | — |
| Trajectory | `milkoor/causetrace@c7fce56f58e21368e4454e5cd830c3a1afc9c262` | REFERENCE / LATER | MIT | — |
| Communication | `phronesis-io/eigenflux@8d9679a7c89d9d87d5e580c610a4abebd541f296` | REFERENCE / LATER | modified Apache-2.0 | — |
| SaaS | `oomol-lab/open-connector@5960f2ac0fe3e07a61c1c466e98157ad7e80b373` | FUTURE / NOT NOW | Apache-2.0 | — |
| Search infra | `Dicklesworthstone/coding_agent_session_search@a1509629e20eae5e454703dd22549093b0aa5224` | REFERENCE ONLY | MIT + rider | — |

## 7. Hard Ban

默认不从零造 Canvas engine、pan/zoom/selection、graph layout、drag-drop、tree virtualization、Markdown renderer、code editor、diff engine、terminal emulator、PTY、Git parser、installer/updater、Universal Agent RPC、cloud sync、Secrets system、tracing backend、第二 Governance、第二 Project registry/Profile/Memory/Task manager、Runtime checkpoint、scheduler/orchestrator。没有 canonical `task_source` 时不做 Task Board；Conversation lifecycle 不当 TaskState；History 不当 Runtime；Mounted Memory 不当 Injected Context；点击 Send 不直接改变 RuntimeState。

**Final rule：先复用，再证明必须自研；先保留 provenance，再 COPY；先解决当前明确缺口，再研究新 donor。**
