# Yunmin Workbench · E Executor Handoff Pack

这是给“干活的执行 Agent”的最小充分包，不是顾问资料库。

## 先读什么
1. `00-EXECUTOR-PROMPT.txt`：本轮执行合同。
2. `Yunmin-Workbench-E-Long-Term-Baseline-FROZEN-v2-2026-08-27.txt`：当前执行基准；优先于历史文档。
3. `Yunmin-Workbench-REUSE-MAP-FINAL-v2-2026-08-27.md`：Reuse / donor / license 正本。
4. `Yunmin-Workbench-项目完整描述.pdf|docx`：历史产品合同，只在需要理解产品边界时读取。

PDF 版 Product Book 给人看；TXT 版给 Agent 读。不要把旧 Current Memory Baseline、旧 REUSE-MAP、D 机交接文件重新加入执行上下文，它们已被当前两份正本吸收，低级模型读太多反而容易漂移。

仓库自身的 `README.md`、`THIRD_PARTY_NOTICES.md`、package/test/e2e 文件必须由执行 Agent直接从当前 E clone 读取，不能使用这个包里的静态副本。

当前任务只有 CLEAN-ROOM GREEN；完成后再进入 History/Search。
